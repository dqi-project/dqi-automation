package com.dqi.xlapper.config.model;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import com.dqi.xlapper.util.Utility;

@Component
@ConfigurationProperties(prefix = "copysheet")
public class CopySheet {
	String sourFile;
	String destFile;
	List<SourDestSheet> sourDestSheets = new ArrayList<>();
	public String getSourFile() {
		return sourFile;
	}
	public void setSourFile(String sourFile) {
		this.sourFile = sourFile;
	}
	public String getDestFile() {
		return destFile;
	}
	public void setDestFile(String destFile) {
		this.destFile = destFile;
	}
	public List<SourDestSheet> getSourDestSheets() {
		return sourDestSheets;
	}
	public void setSourDestSheets(List<SourDestSheet> sourDestSheets) {
		this.sourDestSheets = sourDestSheets;
	}
	@Override
	public String toString() {
		return "CopySheet [sourFile=" + sourFile + ", destFile=" + destFile + ", sourDestSheets=" + sourDestSheets
				+ "]";
	}
	public void copyData(){
		if(sourDestSheets!=null) {
		for(SourDestSheet sds : sourDestSheets) {
			if(sds.getRowsCellsType()!=null) {
				for(String loc : sds.getRowsCellsType()) {
					sds.getRowCells().add(Utility.getRowCol(loc));
				}
			}
		}
		}
	}
}

