package com.dqi.xlapper.config.model;

import java.util.ArrayList;
import java.util.List;

public class SourDestSheet {
	String sourSheet ;
	String destSheet;
	List<String> rowsCellsType = new ArrayList<>();
	List<RowCell> rowCells = new ArrayList<>();
	public String getSourSheet() {
		return sourSheet;
	}
	public void setSourSheet(String sourSheet) {
		this.sourSheet = sourSheet;
	}
	public String getDestSheet() {
		return destSheet;
	}
	public void setDestSheet(String destSheet) {
		this.destSheet = destSheet;
	}
	public List<String> getRowsCellsType() {
		return rowsCellsType;
	}
	public void setRowsCellsType(List<String> rowsCellsType) {
		this.rowsCellsType = rowsCellsType;
	}
	public List<RowCell> getRowCells() {
		return rowCells;
	}
	public void setRowCells(List<RowCell> rowCells) {
		this.rowCells = rowCells;
	}
	@Override
	public String toString() {
		return "SourDestSheet [sourSheet=" + sourSheet + ", destSheet=" + destSheet + ", rowsCellsType=" + rowsCellsType
				+ ", rowCells=" + rowCells + "]";
	}
	
	
}
