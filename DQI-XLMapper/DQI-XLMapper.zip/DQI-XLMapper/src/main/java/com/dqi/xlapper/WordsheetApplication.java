package com.dqi.xlapper;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.dqi.xlapper.config.model.CopySheet;
import com.dqi.xlapper.util.Utility;

@SpringBootApplication
public class WordsheetApplication implements CommandLineRunner{

	   
	   @Autowired
	    private CopySheet copySheet;
	   
	   
	public static void main(String[] args) {
		SpringApplication.run(WordsheetApplication.class, args);
	} 
	
	@Override
    public void run(String... args)  {
		 System.out.println(copySheet);
		 copySheet.copyData();
        System.out.println(copySheet);
        try {
			boolean val = Utility.CopyExcel(copySheet);
			System.out.println(val);
		} catch (IOException e) {
			System.out.println("Error : "+e);
			e.printStackTrace();
		}
        
	}
}
