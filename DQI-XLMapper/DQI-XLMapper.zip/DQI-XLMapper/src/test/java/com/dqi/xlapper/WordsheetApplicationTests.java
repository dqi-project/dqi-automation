package com.dqi.xlapper;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WordsheetApplicationTests {

	@Test
	void contextLoads() {
	}

}
